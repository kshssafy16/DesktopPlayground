# FRAME MAPPING — call_duck (QA revised)

This revised package assembles a **1536 x 1872px** transparent WebP spritesheet for DesktopPlayground.

## Sheet contract
- Sheet size: 1536 x 1872 px
- Grid: 8 columns x 9 rows
- Cell size: 192 x 208 px
- Zero-based coordinates: `left = col * 192`, `top = row * 208`
- Origin: `feet`
- Center: `0.5`
- Foot anchor: `192 / 208 = 0.9230769230769231`
- Transparent background: yes
- `walkLeft` mirrors `walkRight`

## Used rows
- Row 0: idle (cols 0-7)
- Row 1: walkRight (cols 0-7), walkLeft uses mirror
- Row 2: reserved blank row kept intentionally for future authored left-walk or alternates
- Row 3: jump/fall/land (cols 0-7)
- Row 4: grabStart/drag/release (cols 0-7)
- Row 5: sleep/rest/wake (cols 0-7), reordered for smoother progression
- Row 6: hit/stunned (cols 0-3), cols 4-7 intentionally blank reserved space
- Row 7: look (cols 0-7)
- Row 8: reserved blank row kept intentionally for future extra poses

## Clip mapping
| Clip | Row | Columns | Notes |
|---|---:|---|---|
| idle | 0 | 0-7 | blink, sway, small wing movement |
| walkRight | 1 | 0-7 | revised alignment to stabilize body center and foot baseline |
| walkLeft | 1 | 0-7 mirrored | mirrored from walkRight |
| jump | 3 | 0-2 | crouch, lift, takeoff |
| fall | 3 | 3-4 | airborne descent |
| land | 3 | 5-7 | touchdown, squash, recovery |
| grabStart | 4 | 0-1 | surprise then lifted |
| drag | 4 | 2-5 | held / dangling loop |
| release | 4 | 6-7 | drop and recover |
| sleep | 5 | 0 | full tucked sleeping pose |
| rest | 5 | 1-4 | awake loaf -> drowsy -> sleepy breathing |
| wake | 5 | 5-7 | waking -> upright recovery |
| hit | 6 | 0-2 | brief flinch / recoil / recovery |
| stunned | 6 | 3 | dizzy hold |
| look | 7 | 0-7 | look-around and wing-tidy gesture |

## QA revision summary
- Re-centered walkRight frames to reduce perceived lateral wobble in the middle frames.
- Rechecked jump / fall / land to preserve foot visibility and cell margins.
- Rechecked grab / drag / release so held poses share a more stable center.
- Reordered row 5 for cleaner sleep -> rest -> wake progression.
- Kept row 2, row 8 and row 6 cols 4-7 as reserved transparent areas on purpose.

## Validation checklist
- WebP opens successfully
- Alpha transparency preserved
- Grid geometry matches JSON
- Referenced frames point only to populated cells
- Reserved cells documented explicitly
